const backtest = (params) => {
  const lotSize = 75;
  const {
    numOfTradesInADay = 1,
    dailyStopLoss,
    dailyTarget,
    numOfLots = 1,
    taxAndBrokeragePerTrade = 125,
    strategy = [],
  } = params;

  const randomNumber = (n) => parseInt(Math.random() * n);

  const calculateAmount = (priceChange) => lotSize * numOfLots * priceChange;
  // const possibleOutcomes = [
  //   { amount: calculateAmount(-50), probability: 50 },
  //   { amount: calculateAmount(0), probability: 25 },
  //   { amount: calculateAmount(100), probability: 25 },
  // ].reduce((result, outcome, index, outcomes) => {
  const possibleOutcomes = strategy.reduce((result, outcome, index) => {
    let { probability, points } = outcome;
    const amount = calculateAmount(points);

    if (index > 0) {
      probability += result[index - 1].probability;
    }

    return [...result, { probability, amount }];
  }, []);

  const randomOutcome = () => {
    const random100 = randomNumber(100);
    const outcome = possibleOutcomes.find(
      ({ probability }) => random100 < probability
    );

    return outcome ? outcome.amount : 0;
  };

  let sum = 0;
  for (let i = 0; i < numOfTradesInADay; i++) {
    const pnl = randomOutcome() - taxAndBrokeragePerTrade;
    sum += pnl;

    if (
      (dailyStopLoss && sum <= dailyStopLoss) ||
      (dailyTarget && sum >= dailyTarget)
    ) {
      return sum;
    }
  }

  return sum;
};

const average = (fn, sampleSize) => {
  let sum = 0;
  for (let i = 0; i < sampleSize; i++) {
    sum += fn();
  }

  return sum / sampleSize;
};

const options = {
  numOfTradesInADay: 1,
  // dailyTarget: 1000,
  // dailyStopLoss: -1000,
  numOfLots: 1,
  taxAndBrokeragePerTrade: 125,
  strategy: [
    { points: 50, probability: 50 },
    { points: -40, probability: 50 }
  ]
};

console.log(
  "PNL",
  average(() => backtest(options), 1000000)
);
