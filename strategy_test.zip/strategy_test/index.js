const { backtest } = require("./strategy");
const { readCsvInBatches } = require("./read_file");
const { delay } = require("./delay");

const BATCH_SIZE = 375; // number of minutes in trading session
// const filePath = "./data_dumps/NIFTY_50_trimmed.csv";
const filePath = "./data_dumps/NIFTY_50.csv";

const processBatch = () => {
  let totalPnl = 0;
  let totalTargetCount = 0;
  let totalStoplossCount = 0;

  readCsvInBatches(
    filePath,
    BATCH_SIZE,
    (data) => {
      const stableData = data.slice(30);

      console.log(`Date:${stableData[0]?.date}`);
      const { pnl, targetCount, stoplossCount } = backtest(stableData);

      totalPnl += pnl;
      totalTargetCount += targetCount;
      totalStoplossCount += stoplossCount;

      const winningProbability = totalTargetCount * 100 / (totalTargetCount + totalStoplossCount);

      console.log(
        `Total P&L: ${totalPnl}`,
        `| TRGT: ${totalTargetCount}, SL: ${totalStoplossCount}`,
        `| Winning Probability: ${winningProbability.toFixed(2)}`
      );
      console.log("=======================================")
      // delay(10);
    }
  );
}

processBatch();
