// const moment = require("moment");
// const { delay } = require("./delay");

const getFormattedCandleData = (candleData) => {
  const { date, open, high, low, close } = candleData;
  return {
    // date: moment(date),
    date,
    open: parseInt(open),
    high: parseInt(high),
    low: parseInt(low),
    close: parseInt(close),
  };
}

const tradeDecision = (previousTrade) => {
  if (previousTrade?.stoplossHit) {
    return previousTrade.buyOrSell * -1;
  } else if (previousTrade?.targetHit) {
    return previousTrade.buyOrSell;
  }

  const randomNumber = (n) => parseInt(Math.random() * n);

  const random100 = randomNumber(100);
  return random100 > 50 ? 1 : -1; // 1 => buy and -1 => sell
};

const trade = (candlesData, target, stoploss, previousTrade) => {
  const { open: tradePrice } = getFormattedCandleData(candlesData[0]);
  const buyOrSell = tradeDecision(previousTrade);

  const calculatePnl = (currentPrice, high, low) => {
    if (buyOrSell === 1) {
      if (low - tradePrice <= stoploss) return stoploss;
      if (high - tradePrice >= target) return target;
    } else if (buyOrSell === -1) {
      if (tradePrice - high <= stoploss) return stoploss;
      if (tradePrice - low >= target) return target;
    }

    return (currentPrice - tradePrice) * buyOrSell;
  }

  let pnl = 0;
  let index = 0;
  for (index = 0; index < candlesData.length; index++) {
    const { close: currentPrice, high, low, date } = getFormattedCandleData(candlesData[index]);
    pnl = calculatePnl(currentPrice, high, low);
    // console.log("MINUTE", buyOrSell === 1 ? "BUY" : "SELL", date, pnl, tradePrice, currentPrice, high, low, target, stoploss);

    if (pnl <= stoploss) {
      return { pnl: stoploss, index, stoplossHit: 1, buyOrSell };
    }

    if (pnl >= target) {
      return { pnl: target, index, targetHit: 1, buyOrSell };
    }
  }

  return { pnl, index, buyOrSell };
}

const backtest = (candlesData = []) => {
  const lotSize = 75;
  const numOfTradesInADay = 1;
  const numOfLots = 1;
  const taxAndBrokeragePerTrade = 125;

  const target = 150; // Nifty points
  const stoploss = -50;

  // const dailyStopLoss = -3500;
  // const dailyTarget;

  const calculateAmount = (priceChange) => lotSize * numOfLots * priceChange;

  let sum = 0;
  let index = 0;
  let stoplossCount = 0;
  let targetCount = 0;
  let previousTrade;
  for (index = 0; index < candlesData.length; index++) {
    const tradeResult = trade(candlesData.slice(index), target, stoploss, previousTrade);
    const {
      pnl,
      index: nextIndex,
      buyOrSell,
      targetHit,
      stoplossHit
    } = tradeResult;

    sum += calculateAmount(pnl) - taxAndBrokeragePerTrade;
    index += nextIndex + 15; // wait for 10 minute before executing next trade.
    stoplossCount += stoplossHit || 0;
    targetCount += targetHit || 0;

    previousTrade = tradeResult;
    console.log("TRADE", buyOrSell === 1 ? "BUY" : "SELL", pnl, `Day's P&L: ${sum}`);

    // if (dailyStopLoss && sum < dailyStopLoss) break;
  }

  return {
    pnl: sum,
    targetCount,
    stoplossCount,
  };
};

module.exports = {
  backtest,
}
