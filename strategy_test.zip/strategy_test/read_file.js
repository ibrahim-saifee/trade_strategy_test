const fs = require("fs");
const csv = require("csv-parser");

function readCsvInBatches(filePath, batchSize, processBatch, endProccessing) {
  const batch = [];

  fs.createReadStream(filePath)
    .pipe(csv())
    .on("data", (row) => {
      batch.push(row);
      if (batch.length === batchSize) {
        processBatch([...batch]);
        batch.length = 0; // Clear the batch
      }
    })
    .on("end", () => {
      if (batch.length > 0) {
        processBatch(batch); // Process remaining rows
      }
      endProccessing && endProccessing();
    })
    .on("error", (err) => {
      console.error("Error reading CSV file:", err);
    });
}

module.exports = { readCsvInBatches };
